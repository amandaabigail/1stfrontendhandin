// CLICK EVENT

// Match selected first letter with array index 

let selectALetter = document.querySelector("#selectLetter");
let chosenLetter = document.querySelectorAll("#selectLetter option");
const letterArray = ['Perky', 'Bubbles', 'Phoenix', 'Shiny', 'Sparkles', 'Sunshine',
                    'Chipper', 'Twinkle', 'Sunny', 'Jolly', 'Colorful', 'Happy',
                    'Daydream', 'Crazy', 'Awesome', 'Starlight', 'Silly', 'Rainbow',
                    'Magnificent', 'Princess', 'Giddy', 'Lovely', 'Dandelion', 'Fancy',
                    'Buttercup', 'Sassya', 'Fabilous', 'Diamond', 'Golden'];

function compareLetterValues(item, index) {
    let selectedOption = selectALetter.options[selectALetter.selectedIndex].value;
    if(selectedOption == index) {
        document.querySelector('#firstName').innerHTML = '"'+item; 
    }
}
// Match selected month with array index


let selectAMonth = document.querySelector("#selectMonth");
let chosenMonth = document.querySelectorAll("#selectMonth option");
const monthArray = ['Twinkle Toes', 'Sugar Socks', 'Dainty Eyes', 'Happy Feet',
                    'Snowy Hooves', 'Floating Bubbles', 'Summer Dream',
                    'Blue Berry', 'Silver Moon', 'Golden Tail', 'Glitter Love',
                    'Candy Reins'];

function compareMonthValues(item, index) {
    let selectedOption = selectAMonth.options[selectAMonth.selectedIndex].value;
    if(selectedOption == index) {
        document.querySelector('#secondName').innerHTML = item+'"'; 
    }
}

let unicornContent = document.querySelector("#yourUnicorn");
let keyPress = document.querySelector(".keyEvent");

// Change opacity value to 1
function showUnicorn() {
    unicornContent.style.transition = "1s opacity";
    unicornContent.style.webkitTransition = "1s opacity";
    unicornContent.style.opacity = "1";

    keyPress.style.transition = "1s opacity";
    keyPress.style.webkitTransition = "1s opacity";
    keyPress.style.opacity = "1"; 
}

// Add event listener for Submit button

let unicornBtn = document.querySelector("#submit");

unicornBtn.addEventListener("click", function() {
    letterArray.forEach(compareLetterValues);
    monthArray.forEach(compareMonthValues);
    showUnicorn();
});


// KEYPRESS EVENT

let keyEventImg = document.querySelector(".keyEvent img");
keyEventImg.classList.remove("animKey");

document.body.addEventListener("keydown", function() {
    keyEventImg.classList.add("animKey");
});


// MOUSEOVER EVENT

let mouseOver = document.querySelector("#mouseover");
mouseOver.addEventListener("mouseover", function() {
    
    document.body.style.backgroundColor = "#1f1f1f";
    document.body.style.color = "#484848";
    mouseOver.innerHTML = "Surprize...";
    
    let content = document.querySelectorAll(".content");

   content.forEach(function(item) {
    item.style.backgroundColor = "#1b1b1b";
    item.style.boxShadow = "0 1px 8px 0 #0e0e0e";
   });

});

// PLAY EVENT

let video = document.querySelector("video");

video.addEventListener("play", function() {
    video.style.transform = "rotate(180deg)";
    video.style.webkitTransform = "rotate(180deg)";
});


// LOAD EVENT

let loadH3 = document.querySelector("#onLoad");
loadH3.classList.remove("animLoad");

document.addEventListener("DOMContentLoaded", function() {
    loadH3.classList.add("animLoad");
});

// DRAG/DROP EVENT

let dragElement = document.querySelector("#dragMe");
let dropElement = document.querySelector("#drop");

document.addEventListener("dragover", function(event) {
    // By default, data/elements cannot be dropped in other elements. 
    // To allow a drop, we must prevent the default handling of the element.
    event.preventDefault();
}, false);


dragElement.addEventListener("dragstart", function(event) {
    //The dataTransfer.setData() method sets the data type and the value of the dragged data:
    event.dataTransfer.setData("text", event.target.id);
}, false);

dropElement.addEventListener("drop", function(event) {
    event.preventDefault();
    let data = event.dataTransfer.getData("text");
    event.target.appendChild(document.getElementById(data));

    dragElement.style.backgroundColor = "#ffe7d3";
    dropElement.style.borderColor = "#ffe7d3";
}, false);


// SCROLL EVENT

window.addEventListener("scroll", function() {
    document.querySelector("#scroll h3").innerHTML = "You've scrolled "+pageYOffset+"px!";
});